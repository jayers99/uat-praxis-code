# Opinions Framework

A structured set of first principles, quality gates, and guidance for each Domain × Lifecycle Stage cell in the Praxis AI governance system.

## Overview

The Opinions Framework provides research-backed guidance for AI-assisted work across different domains and lifecycle stages. It integrates with Praxis's policy engine to ensure quality and consistency in AI-generated artifacts.

## Project Intent

This project defines and documents the aspirational opinions framework for Praxis, producing:

1. **Structured Documentation**: Opinions that guide AI-assisted work within each domain at each stage
2. **Policy Integration**: A defined contract for integration with Praxis's policy engine
3. **Research-Backed Principles**: Based on key influencers, first principles, and consensus

## Structure

- **`docs/`** - Framework documentation and research
  - Story documents defining project phases
  - Prerequisite research and spikes
  - Opinion contract drafts
  - Process documentation
- **`praxis.yaml`** - Project configuration

## Domain & Stage

- **Domain**: Write
- **Stage**: Capture
- **Privacy Level**: Public
- **Environment**: Home

## Key Documentation

- [`docs/capture.md`](docs/capture.md) - Project capture document with intent and strategy
- [`docs/opinions-contract-draft.md`](docs/opinions-contract-draft.md) - Draft contract for policy integration
- [`docs/00-prerequisites/`](docs/00-prerequisites/) - Research spikes on lifecycle and domains

## History

This repository was extracted from the `jayers99/praxis-ai` repository, preserving the git history of the `projects/write/opinions-framework/` directory. The extraction was performed to enable independent development and versioning of the opinions framework.

**Original Location**: `projects/write/opinions-framework/` in [jayers99/praxis-ai](https://github.com/jayers99/praxis-ai)

## Contributing

See the story documents in `docs/` for current work items and project phases.

## License

See [LICENSE](LICENSE) file (if applicable - inherited from parent repository).
